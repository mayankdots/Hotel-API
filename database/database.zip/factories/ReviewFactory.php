<?php

namespace Database\Factories;

use App\Models\Hotel;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReviewFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $rates = [1, 2 ,3, 4, 5];
        $hotels = Hotel::pluck('id')->toArray();
        return [
            'hotel_id' => $this->faker->randomElement($hotels),
            'review_title' =>  $this->faker->sentence,
            'author' => $this->faker->name(),
            'rating' => $rates[rand(0,4)],
            'description' => $this->faker->realText,
        ];
    }
}
